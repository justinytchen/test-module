#!/bin/bash
# This script uninstalls vsoagent as a systemd service

servicename="vsoagent.service"

echo "Uninstalling Service $servicename"

# Exit if service does not exist
systemctl cat $servicename > /dev/null 2>&1 
rc=$?
if [ $rc -ne 0 ]
then
	echo "Service $servicename is not installed"
	exit $rc
fi

isActive=`systemctl is-active $servicename`
if [ "$isActive" == "active" ]
then
	systemctl stop $servicename
fi

systemctl reset-failed $servicename
systemctl disable $servicename
rm /etc/systemd/system/$servicename
systemctl daemon-reload

echo "Service $servicename has been uninstalled!"

