
#input
$SERVER=$args[0]
$COMMIT_ID=$args[1]
$PORT_MARKER=$args[2]
$QUALITY=$args[3]
$EXTENSIONS=$args[4]
$TELEMETRY=$args[5]

Write-Output "|============= vscode-win-install.ps1 Arguments ==============="
Write-Output "|      SERVER: $SERVER"
Write-Output "|   COMMIT_ID: $COMMIT_ID"
Write-Output "| PORT_MARKER: $PORT_MARKER"
Write-Output "|     QUALITY: $QUALITY"
Write-Output "|  EXTENSIONS: $EXTENSIONS"
Write-Output "|   TELEMETRY: $TELEMETRY"
Write-Output "|=============================================================="
Write-Output "Printing the current environment variables..."
gci env:

$START_TIME = Get-Date
Import-Module BitsTransfer

$ErrorActionPreference = "Stop"

#setup
$VSCH_HOME="$HOME\.vscode-remote"
$VSCH_DIR="$VSCH_HOME\bin\$COMMIT_ID"
$VSCH_LOGFILE="$VSCH_HOME\.$COMMIT_ID.log"
$VSCH_ERR_LOGFILE="$VSCH_HOME\.$COMMIT_ID.err.log"
$VCSH_ZIP="vscode-server-win32-x64-web.zip"
$VSCH_DOWNLOAD="https://update.code.visualstudio.com/commit:$COMMIT_ID/$SERVER/$QUALITY"


function pollLogFile($timeoutSeconds) {
    Write-Output "Polling logfile [$VSCH_LOGFILE] ..."
    $timeoutDate = (Get-Date).AddSeconds($timeoutSeconds)
    
    while ((Get-Date) -lt $timeoutDate) {
        if (Test-Path $VSCH_LOGFILE -PathType Leaf) {
            if ($Null -ne (Get-Content $VSCH_LOGFILE | Select-String -Pattern "Extension host agent listening on" -AllMatches)) {
                break
            }
        }
        Start-Sleep -m 500
        Write-Output "Waiting for server log..."
    }

    if (Test-Path $VSCH_LOGFILE) {
        $port = Get-Content $VSCH_LOGFILE | Select-String -Pattern "Extension host agent listening on ([0-9]+)" -AllMatches | Select-Object -Last 1 | ForEach-Object {$_.matches.groups[1].Value}
    }
    if (!$port) {
        Write-Output "Server did not start successfully."
        if (Test-Path $VSCH_LOGFILE -PathType Leaf) {
            Write-Output "Full stdout >>>"
            Get-Content $VSCH_LOGFILE
            Write-Output "<<< End stdout"
        }
        if (Test-Path $VSCH_ERR_LOGFILE -PathType Leaf) {
            Write-Output "Full stderr >>>"
            Get-Content $VSCH_ERR_LOGFILE
            Write-Output "<<< End stderr"
        }
        return
    }
    Write-Output "$PORT_MARKER==$port==$PORT_MARKER"
}
function installServer {
    # download/unpack VS SaaS agent
	Write-Output "Installing..."
    mkdir -Force $VSCH_DIR | out-null
	Set-Location $VSCH_DIR
    try {
        Start-BitsTransfer -Source $VSCH_DOWNLOAD -Destination ".\$VCSH_ZIP"
        Write-Output "Start-BitsTransfer succeeded."
    } catch {
        Write-Output "Start-BitsTransfer failed. Falling back to WebClient..."
        $webClient = New-Object System.Net.WebClient
        $webClient.DownloadFile($VSCH_DOWNLOAD, "$VSCH_DIR\$VCSH_ZIP")
    }
    Write-Output "(*) Finished Download"
    Start-Process -FilePath "$PSScriptRoot\7za.exe" -ArgumentList "x",".\$VCSH_ZIP" -Wait -NoNewWindow -RedirectStandardOutput "NUL"
    Write-Output "(*) Finished Expand"
    Remove-Item ".\$VCSH_ZIP"
    # pull out of inner folder
    $innerFolder = Get-ChildItem -Path . -Force -Recurse -Directory | Select-Object -First 1 | ForEach-Object {$_.Name}
    Get-ChildItem -Path "$VSCH_DIR\$innerFolder" -Recurse | Move-Item -Destination "$VSCH_DIR"
    Remove-Item "$VSCH_DIR\$innerFolder"

    # cheap sanity check
	if (!(Test-Path "$VSCH_DIR/node.exe" -PathType Leaf)) {
		Write-Output "WARNING: $VSCH_DIR/node doesn't exist. Download/untar may have failed."
	}
	if (!(Test-Path "$VSCH_DIR/server.cmd" -PathType Leaf)) {
		Write-Output "WARNING: $VSCH_DIR/server.cmd doesn't exist. Download/untar may have failed."
    }
}
function installExtensions($waitSeconds) {
    # install extensions
    Write-Output "Installing extensions (waiting max $waitSeconds seconds)..."
    $extensionsLogFile = "$VSCH_HOME\.extensions-$COMMIT_ID.log"
    $extensionsErrLogFile = "$VSCH_HOME\.extensions-$COMMIT_ID.err.log"
    $extensionsProcess = Start-Process -FilePath "$VSCH_DIR\server.cmd" -ArgumentList "$TELEMETRY","$EXTENSIONS" -NoNewWindow -RedirectStandardOutput $extensionsLogFile -RedirectStandardError $extensionsErrLogFile -PassThru
    Wait-Process -Id $extensionsProcess.Id -Timeout $waitSeconds
}
function startServer {
    if (!(Test-Path "$VSCH_DIR/package.json" -PathType Leaf)) {
	    installServer
    } else {
	    Write-Output "Found existing installation..."
    }
    # launch if needed
    if (Get-WmiObject Win32_Process | Select-Object name, commandline | Where-Object {$_.name -eq "node.exe" -and $_.commandline -like "*$VSCH_DIR\node.exe*"}) {
	    Write-Output "Found running server..."
    }
    else {
        Write-Output "Starting server..."
        Write-Output "Logfile: $VSCH_LOGFILE"
        Write-Output "Error Logfile: $VSCH_ERR_LOGFILE"
        Start-Process -FilePath "$VSCH_DIR\server.cmd" -ArgumentList "--connectionToken=$COMMIT_ID","--enable-remote-auto-shutdown","--port=0","--host=localhost","$TELEMETRY" -NoNewWindow -RedirectStandardOutput $VSCH_LOGFILE -RedirectStandardError $VSCH_ERR_LOGFILE
    }
    pollLogFile -timeoutSeconds 30
}

# Acquire lock
$lockPath = (Join-Path $VSCH_HOME "vscode-remote-lock.$COMMIT_ID")
try {
    $null = New-Item $VSCH_HOME -ItemType Directory -ErrorAction SilentlyContinue
    $null = New-Item $lockPath -ItemType File -ErrorAction SilentlyContinue
    $lockFile = [System.io.File]::Open($lockPath, 'Open', 'Read', 'None')
} catch {
    Write-Output "Lock file unavailable. - $($_.ToString())"
    # Presumably, the script is already setting things up. Let's just watch the logfile.
    pollLogFile -timeoutSeconds 60
    return
}
try {
    startServer
    if ($null -ne $EXTENSIONS) {
        installExtensions -waitSeconds ([math]::max(0, [math]::floor(8 - ((Get-Date) - $START_TIME).TotalSeconds)))
    }
} catch {
    Write-Output "vscode-server failed to start. - $($_.ToString())"
} finally {
    $lockFile.Close()
}