#!/usr/bin/env bash

source $1