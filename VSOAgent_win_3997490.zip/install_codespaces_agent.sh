#!/bin/bash
# This script installs vsoagent as a systemd service

servicename="vsoagent.service"

echo "Installing Service $servicename ..."

# Set execuctable basepath for the service
sed "s|{BITS_DIR}|`pwd`|g" vsoagent.service > /etc/systemd/system/vsoagent.service

cp codespaces vso

# Set permissions for the Unit file and executable
chmod 644 /etc/systemd/system/vsoagent.service
chmod +x vso # copy of cli with old name needed for old kitchensink that has it as run argument
chmod +x codespaces
chmod +x vsls-agent
chmod +x sourcer.sh
chmod +x sourcer.zsh
chmod +x Docker/linux-prereqs.sh

# Install credential manager in VM
git config --system --add credential.helper '/.vsonline/vsoagent/bin/codespaces gitCredential'

# Reload damoen since Unit file is new/modified
systemctl daemon-reload  

# Enable service to start on boot
systemctl enable /etc/systemd/system/vsoagent.service
rc=$?
if [ $rc -ne 0 ]
then
	echo "Service $servicename failed to install!"
	exit $rc
fi

isEnabled=`systemctl is-enabled $servicename`
if [ "$isEnabled" == "enabled" ]
then
	echo "Service $servicename has been successfully installed!"
	echo "Run following command to start the service"
	echo "sudo systemctl start $servicename"
else
	echo "Failed to enable service after installation";
	exit 1
fi

