#!/usr/bin/env zsh

source $1