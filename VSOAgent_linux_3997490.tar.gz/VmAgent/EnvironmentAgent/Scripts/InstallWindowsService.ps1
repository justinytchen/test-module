param
(
    [string] $serviceName = "vsonline-agent",
    [string] $publishLocation = "$PSScriptRoot\..\..\..\..\..\..\bin\Debug\VSOnline.Agent\win7-x64\publish"
)

$ErrorActionPreference = "Stop"

$publishLocation = (Resolve-Path $publishLocation).Path
Write-Host "Publish location: $publishLocation"

$cliCommand = "sc.exe create `"$serviceName`" binpath= `"`\`"$publishLocation\codespaces.exe`\`" vmagent --service`" start= auto"
Write-Host "Executing the following command:"
Write-Host $cliCommand
cmd /c $cliCommand

if ($LASTEXITCODE -ne 0)
{
    throw "Error installing the VM agent as a Windows service."
}