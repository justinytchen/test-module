# Script file called by the Azure custom script extension during Windows VM deployment.
# Preps the machine for running the VM agent on reboot.
# Errors here should fail the script and exception will be caught in outer script and fail the custom script extension deployment.
param
(
    [string] $vsoAgentDir,
    # Base 64 encoded (UTF8) json blob. No nested json as this is parsed into a hashtable<string, string>
    [string] $base64ParametersBlob,
    [string] $logFile
)

$ErrorActionPreference = "Stop"

function Log ([string] $message)
{
    Write-Host $message
    $message = "[$(Get-Date -Format o)] $message $([Environment]::NewLine)"
    [System.IO.File]::AppendAllText($logFile, $message)
}

function ThrowIfKeyNotSet($hashtable, $key)
{
    Log "Ensuring parameter '$key' exists..."
    if (-Not $parameters[$key])
    {
        throw "Required parameter '$key' not found.'"
    }
}

Log "Parsing parameters blob..."
$parametersJsonBlob = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($base64ParametersBlob))

$parameters = @{}
(ConvertFrom-Json $parametersJsonBlob).psobject.properties | Foreach { $parameters[$_.Name] = $_.Value }

$firstBoot = $parameters.ContainsKey("firstBoot")

# Ensure we have parameters we need.
ThrowIfKeyNotSet $parameters "inputQueueName"
ThrowIfKeyNotSet $parameters "inputQueueUrl"
ThrowIfKeyNotSet $parameters "inputQueueSasToken"
ThrowIfKeyNotSet $parameters "vmToken"
ThrowIfKeyNotSet $parameters "resourceId"
ThrowIfKeyNotSet $parameters "serviceHostName"
ThrowIfKeyNotSet $parameters "userName"
ThrowIfKeyNotSet $parameters "visualStudioInstallationDir"

$configIni = [IO.Path]::Combine($vsoAgentDir, "config.ini")

if (Test-Path $configIni -PathType Leaf)
{
    Remove-Item $configIni -Force
}

Log "Writing config.ini..."
Add-Content $configIni "[ENVAGENTSETTINGS]"
Add-Content $configIni "INPUTQUEUENAME=$($parameters['inputQueueName'])"
Add-Content $configIni "INPUTQUEUEURL=$($parameters['inputQueueUrl'])"
Add-Content $configIni "INPUTQUEUESASTOKEN=$($parameters['inputQueueSasToken'])"
Add-Content $configIni "[HEARTBEATSETTINGS]"
Add-Content $configIni "VMTOKEN=$($parameters['vmToken'])"
Add-Content $configIni "RESOURCEID=$($parameters['resourceId'])"
Add-Content $configIni "SERVICEHOSTNAME=$($parameters['serviceHostName'])"

# TODO: janraj, following lines are temporary hacks to light up nexus.

# TODO: vso vm agent should be running as a service. vso cli should be launched by the vso vm agent.
# Launching an interactive app on a interactive login from a service has proved difficult so far.
# Currently when this script is run as Local System Account, it will author a cmd file in the startup folder
# and do a restart of the box. Once the windows vm restarts, vsonline user will be auto login-ed and also
# the startup cmd will be executed.
Log "Write start up file..."
$visualStudioInstallationDir = $parameters["visualStudioInstallationDir"]
$startUpFile = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp\vsoagent.cmd"

if (Test-Path $startUpFile -PathType Leaf)
{
    Remove-Item $startUpFile -Force
}

if ($firstBoot)
{
    Log "First Boot."

    # Add user to docker group.
    Add-LocalGroupMember -Group docker-users -member $($parameters['userName'])

    # Enable all hyper-v features
    & dism /online /enable-feature /featurename:Microsoft-Hyper-V /Quiet /NoRestart /all

    # Opt-in for host-only time sync
    reg add HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\w32time\TimeProviders\VMICTimeProvider /v Enabled /t REG_DWORD /d 1 /f
    reg add HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\w32time\TimeProviders\NtpClient /v Enabled /t REG_DWORD /d 0 /f
    
    # Temporary check of Datacenter Server. The "net stop" is failing for some reason.
    $osInfo = Get-ComputerInfo -Property Os*
    if ($osInfo.OsOperatingSystemSKU -ne "DatacenterServerEdition")
    {
        & net stop w32time
        & net start w32time
    }

    # Add a PS Profile script for All Users, Current Host to always reload the environment variables
    $reloadVariablesCommand = '$env:Path=[System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")'
    $profilePath = $PROFILE.AllUsersCurrentHost

    # If profile does not exist, simply write the env var reload command
    if ((Test-Path $profilePath) -eq $False) {
        Write-Output $reloadVariablesCommand > $profilePath
    }
    else {
        # If profile does exist do a simple check if a similar command is already there, if not add it
        $SEL = Select-String -Path $profilePath -Pattern '[$env:Path]\s*[=]' -List

        if (($null -eq $SEL) -or ($SEL.Matches.Length -eq 0)) {
            Add-Content -Path $profilePath -Value $reloadVariablesCommand
        }
    }
}

Log "Starting Docker Desktop"
Add-Content $startUpFile 'start "Docker Desktop" "C:\Program Files\Docker\Docker\Docker Desktop.exe"'

# Then, we need to hide the UI Docker Desktop pops-up
Add-Content $startUpFile "start /min powershell -Command `"$vsoAgentDir\VmAgent\EnvironmentAgent\Scripts\HideDockerDesktop.ps1 -sleep 15 -attempts 0 -keepAlive `$True`""

# Suppress the Shell dialog which checks for the existence of a "c:\program" folder or executable, which can be problematic from a reliability/security perspective.
# We need to suppress this for now, as it can affect agent startup.
Add-Content $startUpFile "reg add HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\DontShowMeThisDialogAgain /v RogueProgramName /t REG_SZ /d no /f"

Log "Configuring git credential plugin"
Add-Content $startUpFile 'git config --system --unset credential.helper'
Add-Content $startUpFile 'git config --system credential.helper "!f() { c:/vsonline/vsoagent/bin/codespaces gitCredential $*; }; f"'

# The following is to add the VSLS-Agent.exe to the firewall exceptions.
Add-Content $startUpFile "netsh advfirewall firewall add rule name=`"VsoVSLS`" dir=in action=allow program=`"$vsoAgentDir\vsls-agent.exe`" enable=yes"

# AppCasting (via SlimCore) has issues if this network tab displays after boot up. It somehow occuludes all windows. Dismissing the pane by pre-selecting a choice.
Add-Content $startUpFile "netsh advfirewall firewall set rule group=`"Network Discovery`" new enable=no"

# Command to launch VSO VMAgent
Add-Content $startUpFile "cd $vsoAgentDir"
Add-Content $startUpFile "$vsoAgentDir\codespaces.exe vmagent"

Copy-Item "$vsoAgentDir\codespaces.exe" "$vsoAgentDir\vso.exe"

# TODO: Once the service can launch vso cli as an interactive process. This will be no longer needed.
# Schedule a restart to run the start up program which starts the VM agent.
if ($firstBoot)
{
    Log "Scheduling restart after first boot in 60 seconds..."
    & $env:SystemRoot\system32\shutdown.exe -r -f -t 60
}
else
{
    Log "Scheduling restart in 5 seconds..."
    & $env:SystemRoot\system32\shutdown.exe -r -f -t 5
}

Log "Finished WindowsInit.ps1."
