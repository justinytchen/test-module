# If no VHD exists on Azure file share, creates an empty VHD on Azure file share and mount VHD to the local drive.
# If a VHD does exist on Azure file share, just mount that VHD.
# Must be ran as admin for local drive access.
param
(
    [Parameter(Mandatory=$true)]
    [string]
    $storageAccountName,
    [Parameter(Mandatory=$true)]
    [string]
    $storageShareName,
    [Parameter(Mandatory=$true)]
    [string]
    $storageAccountKey,
    [Parameter(Mandatory=$true)]
    [string]
    $storageFileServiceHost,
    [Parameter(Mandatory=$true)]
    [string] $vhdName,
    [Parameter(Mandatory=$true)]
    [string] $mountedDriveOutputName,
    [Parameter(Mandatory=$true)]
    [string] $vhdPathOutputName,
    [string] $dockerLibName = "dockerlib",
    # Drive letter to assign to the partition if creating new VHD. If VHD already exists, use existing drive letter.
    [char] $driveLetter = "F",
    [int] $vhdSizeInGb = 64
)

$ErrorActionPreference = "Stop"

Write-Host "Storage account name: $storageAccountName"
Write-Host "Storage share name: $storageShareName"
Write-Host "Storage file service host: $storageFileServiceHost"

$authority = "$storageFileServiceHost"

# Save the password so the drive will persist on reboot.
Write-Host "Adding credentials in Windows Credential Manager for accessing the Azure file share..."
New-StoredCredential -Comment $authority -UserName "Azure\$storageAccountName" -Password $storageAccountKey -Target $authority -Persist Enterprise  -Type DomainPassword

$vhdPath = "\\$authority\$storageShareName\$vhdName"
Write-Host "VHD path: $vhdPath"

if (-Not (Test-Path $vhdPath -PathType Leaf))
{
    if (Test-Path "$($driveLetter):\\" -PathType Container)
    {
        throw "Drive '$driveLetter' is already in use."
    }

    Write-Host "Create, initialize, and format VHD on file share..."
    $size = $vhdSizeInGb * 1GB
    # Disable the disk formatting prompt (-Confirm $false doesn't prevent the prompt from showing up)
    Stop-Service -Name ShellHWDetection
    # Create and initialize the VHD.
    (New-VHD -Path $vhdPath -Dynamic -SizeBytes $size) | Mount-VHD -Passthru | Initialize-Disk -Passthru | New-Partition -DriveLetter $driveLetter -UseMaximumSize | Format-Volume -FileSystem NTFS -Confirm:$false -Force
    Start-Service -Name ShellHWDetection

    if (-Not (Test-Path "$($driveLetter):\\" -PathType Container))
    {
        throw "User disk failed to attached to drive $driveLetter."
    }
}
else
{
    Write-Host "VHD exists, mounting it to drive..."
    # If the VHD exists, just mount it.
    (Get-VHD -Path $vhdPath) | Mount-VHD -Passthru
}

$volumeDriveLetter = ((Get-VHD $vhdPath) | Get-Disk | Get-Partition | Get-Volume).DriveLetter
Write-Host "${mountedDriveOutputName}${volumeDriveLetter}"
Write-Host "${vhdPathOutputName}${vhdPath}"

$dockerLibPath = "\\$authority\$storageShareName\$dockerLibName"
if ((Test-Path $dockerLibPath -PathType Leaf))
{
    Write-Host "Removing dockerlib file."
    Remove-Item $dockerLibPath
}

Write-Host "Finished."